# Aplicacion con aws serverless (API Gateway, SQS, SNS, Trigger)

Back serverless.


POST:

https://dsc4xjme52.execute-api.us-east-1.amazonaws.com/dev/saveSolicitude

    {
        "beneficiary": "MIguel Gomez Saavedra",
        "DNI": "42554133",
        "checkDigit": "1",
        "birthday": "20/03/1994",
        "email":"gomez_saavedra@hotmail.com",
        "amount": "100.00",
        "account": "122121212324342113"
    }

